
function renderDetail(e) {
  const el = $("#detail");
  const budgetNote = e.budget == null ? "予定表に予算の入力なし"
    : (e.budgetRows < e.rows ? `予算の入力は ${e.budgetRows} / ${e.rows} 人分` : "");
  const tiles = [
    ["予算", e.budget == null ? "—" : fmt(e.budget) + " h",
      e.budget == null ? budgetNote : `消化 ${(e.actual / e.budget * 100).toFixed(1)}% · 着地 ${(e.forecast / e.budget * 100).toFixed(0)}%` + (budgetNote ? `（${budgetNote}）` : "")],
    ["予定（〜" + md(DATA.asOf) + "）", fmt(e.planToDate) + " h", `通期予定 ${fmt(e.planFull)} h`],
    ["実績", fmt(e.actual) + " h", `予定比 ${fmtPct(e.rate)}（${fmtSigned(e.diff)} h）`],
    ["着地見込み", fmt(e.forecast) + " h", "実績＋今後の予定"],
    ["前年同時期", e.prev ? fmt(e.prev.toDate) + " h" : "—", e.prev ? `今年は ${fmtPct(pct(e.actual, e.prev.toDate))}（${fmtSigned(e.actual - e.prev.toDate)} h）` : "前年の案件なし"],
    ["前年通期", e.prev ? fmt(e.prev.full) + " h" : "—", e.prev ? `着地見込みは ${fmtPct(pct(e.forecast, e.prev.full))}（${fmtSigned(e.forecast - e.prev.full)} h）` : ""],
  ];
  const notes = buildNotes(e);
  const cur = e.curWeekIndex, n = e.weekly.length, inPer = cur >= 0 && cur < n;   // 今週（期の中の週。期の前・後なら範囲外）
  const cm = e.monthly[e.curMonthIndex];
  const logEnd = DATA.asOf < e.periodEnd ? DATA.asOf : e.periodEnd;
  const weekNote = inPer ? `今週（${e.weekly[cur].wk}）は途中のため色を付けていません。` : cur < 0 ? "期はまだ始まっていません。" : "期は終わっています。";
  el.innerHTML = `
  <div class="card">
    <h1 class="engtitle">${esc(e.name)}${e.mergeLabel ? `<span class="muted">（${esc(e.mergeLabel)}）</span>` : ""} <span class="small">${esc(e.id)}</span>${e.noPlan ? ` <span class="badge">予定表にない案件（実績のみ）</span>` : ""}</h1>
    <div class="meta">
      <span>クライアント <b>${esc(e.client)}</b>（${esc(e.clientCode)}）</span>
      <span>管理グループ <b>${esc(e.group)}</b></span><span>決算月 <b>${esc(e.fyEnd)}</b></span>
      <span>期 <b>${md(e.periodStart)}〜${md(e.periodEnd)}</b>（前年 ${md(e.prevStart)}〜${md(e.prevEnd)}）</span>
      <span>EP <b>${esc(e.ep.join("・") || "—")}</b></span><span>EM <b>${esc(e.em.join("・") || "—")}</b></span>
      <span>前年案件 <b>${e.prev ? esc(e.prev.name) + "（" + esc(e.prev.id) + "）" : "—"}</b></span>
      ${e.mergeNote ? `<span>まとめた案件 <b>${esc(e.mergeNote)}</b>（設定の「個別設定」シート）</span>` : ""}
    </div>
    <div class="tiles">${tiles.map(tileHtml).join("")}</div>
  </div>
  <div class="card">
    <h3>注意が要るもの</h3>
    ${notes.length ? `<ul class="notes">${notes.map(n => `<li>${n}</li>`).join("")}</ul>` : `<div class="muted">特になし</div>`}
  </div>
  <div class="card">
    <h3>月ごとの予算と実績（今期 ${esc(e.periodLabel)} と前年 ${esc(e.prevLabel)}）</h3>
    <div class="legend"><span><i class="box" style="background:var(--s-prev)"></i>前年 実績</span><span><i class="box" style="background:var(--s-actual)"></i>今期 実績</span><span><i class="tick"></i>予算（予定表の月合計）</span></div>
    <div class="chart" id="c-month"></div>
    <div class="table-wrap" style="margin-top:8px">${monthlyTable(e)}</div>
    <div class="small" style="margin-top:4px">${cm ? `${MONTH_LABEL(cm.month)}は ${md(DATA.asOf)} までの実績。前年比は、前年も ${md(DATA.prevAsOf)} までの実績で比べています（前年 実績の行は月全体）。` : ""}${e.planOutside ? `${e.planOutside} は予定表の範囲外のため、予定 0 として集計しています。` : ""}</div>
  </div>
  ${e.split ? splitCard(e) : ""}
  <div class="card">
    <h3>累積時間（予定・実績・前年実績）</h3>
    <div class="legend"><span><i style="background:var(--s-plan)"></i>予定</span><span><i style="background:var(--s-actual)"></i>実績</span>${e.prev ? `<span><i class="dash"></i>前年実績（${esc(e.prevLabel)}）</span>` : ""}</div>
    <div class="chart" id="c-cum"></div>
  </div>
  <div class="card">
    <h3>人ごと・週ごとの実績（色は予定との差）</h3>
    <div class="legend"><span><i class="box" style="background:var(--heat-over-2)"></i>予定より多い</span><span><i class="box" style="background:var(--heat-under-2)"></i>予定より少ない</span><span><i class="box heat-miss-box"></i>予定ありで実績なし</span><span>数字は実績（h）。マウスを乗せると予定も表示</span></div>
    <div class="table-wrap">${heatTable(e)}</div>
    <div class="small" style="margin-top:4px">${weekNote}</div>
  </div>
  <div class="card" id="remain-card">
    <h3>残り期間の予定（${inPer ? "今週" : cur < 0 ? md(e.periodStart) : ""}〜${md(e.periodEnd)}）</h3>
    <div class="legend"><span><i class="box pl-1"></i>〜8h</span><span><i class="box pl-2"></i>〜20h</span><span><i class="box pl-3"></i>〜32h</span><span><i class="box pl-4"></i>32h〜</span>
      <label class="small"><input type="checkbox" id="rm-compact"> 予定のない週を詰める</label></div>
    <div class="small" id="rm-sum" style="margin-bottom:6px"></div>
    <div class="table-wrap" id="rm-wrap"></div>
    <div class="small" style="margin-top:4px">${inPer ? `今週（${e.weekly[cur].wk}）は週全体の予定です。` : ""}数字は予定（h）。${e.planOutside ? `${e.planOutside} は予定表の範囲外です。` : ""}</div>
  </div>
  <div class="card">
    <h3>役職別の予定と実績</h3>
    <div class="table-wrap">${ranksTable(e)}</div>
  </div>
  <div class="card">
    <h3>人ごとの予定と実績</h3>
    <div class="table-wrap">${peopleTable(e)}</div>
  </div>
  <div class="grid2">
    <div class="card">
      <h3>週ごとの差（実績 − 予定）</h3>
      <div class="legend"><span><i class="box" style="background:var(--over)"></i>予定より多い</span><span><i class="box" style="background:var(--under)"></i>予定より少ない</span><span>±${T.weekVarHours}h 超は数値を表示</span></div>
      <div class="chart" id="c-diff"></div>
      <details><summary>週ごとの数値を表で見る</summary><div class="table-wrap" style="margin-top:8px">${weeklyTable(e)}</div></details>
    </div>
    <div class="card">
      <h3>作業内容の内訳（実績）</h3>
      ${actBars(e)}
    </div>
  </div>
  <div class="card" id="log-card">
    <h3>実績ログ（期 ${md(e.periodStart)}〜${md(logEnd)}）</h3>
    <div class="filters">
      <label>氏名 <select id="lg-p"><option value="">すべて</option></select></label>
      <label>月 <select id="lg-m"><option value="">すべて</option></select></label>
      ${e.log && e.log.tagTitle ? `<label>${esc(e.log.tagTitle)} <select id="lg-t"><option value="">すべて</option></select></label>` : ""}
      <label>作業内容 <select id="lg-a"><option value="">すべて</option></select></label>
      <label><input type="search" id="lg-q" placeholder="摘要・作業内容で検索"></label>
      <span id="lg-chip"></span>
      <button type="button" class="btn" id="lg-csv">CSV で保存</button>
    </div>
    <div class="small" id="lg-sum" style="margin-bottom:6px"></div>
    <div class="table-wrap log-wrap" id="lg-wrap"><table class="log"><thead></thead><tbody></tbody></table></div>
    <div class="small" style="margin-top:4px">表の中だけがスクロールします。見出しを押すと並べ替え、上の「人ごと・週ごとの実績」のマスを押すと、その人・その週に絞り込みます。</div>
  </div>`;
  drawMonthly(e);
  drawSplit(e);
  drawCumulative(e);
  drawDiff(e);
  bindHeatTips();
  renderRemaining(e);
  initLog(e);
  const ht = $("table.heat");   // 最新の週が見えるよう右端までスクロール
  if (ht) ht.parentElement.scrollLeft = ht.parentElement.scrollWidth;
}

// ---------- 月ごと ----------
const MONTH_LABEL = m => m + "月";
// 前年比に使う前年の実績（今月は前年も同じ日まで）
const prevCmp = m => m.prevActualToDate != null ? m.prevActualToDate : m.prevActual;
function monthlyTable(e) {
  const sum = (k) => e.monthly.reduce((s, m) => s + (m[k] || 0), 0);
  const has = (k) => e.monthly.some(m => m[k] != null);
  const rows = [
    ["予算", "plan", "今期"], ["実績", "actual", "今期"],
    ["予算", "prevPlan", "前年"], ["実績", "prevActual", "前年"],
  ];
  let h = `<table class="mtable"><thead><tr><th></th><th></th>${e.monthly.map((m, i) => `<th class="num${i === e.curMonthIndex ? " curcol" : ""}" title="${esc(m.ym)}">${MONTH_LABEL(m.month)}</th>`).join("")}<th class="num">合計</th></tr></thead><tbody>`;
  rows.forEach(([lbl, k, fy], ri) => {
    h += `<tr class="${ri === 2 ? "sep" : ""}"><td>${esc(fy)}</td><td>${lbl}</td>` + e.monthly.map((m, i) => `<td class="num${i === e.curMonthIndex ? " curcol" : ""}">${
      k === "plan" && m.planOut ? `<span class="muted" title="予定表の範囲外（予定 0 として集計）">範囲外</span>` : m[k] == null ? `<span class="muted">—</span>` : fmt(m[k])}</td>`).join("") +
      `<td class="num"><b>${has(k) ? fmt(sum(k)) : "—"}</b></td></tr>`;
  });
  // 実績の前年比
  h += `<tr class="sep"><td colspan="2">実績の前年比</td>` + e.monthly.map((m, i) => {
    if (m.actual == null || prevCmp(m) == null) return `<td class="num${i === e.curMonthIndex ? " curcol" : ""}"><span class="muted">—</span></td>`;
    const d = m.actual - prevCmp(m);
    return `<td class="num${i === e.curMonthIndex ? " curcol" : ""} ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td>`;
  }).join("") + `<td></td></tr>`;
  return h + `</tbody></table>`;
}

function drawMonthly(e) {
  const box = $("#c-month"); const W = box.clientWidth, H = 220, m = { l: 48, r: 12, t: 12, b: 24 };
  if (W < m.l + m.r + 60) { box.innerHTML = ""; return; }   // 幅が取れないうちは描かない
  const ms = e.monthly;
  const vals = ms.flatMap(x => [x.plan, x.actual, x.prevPlan, x.prevActual].filter(v => v != null));
  const ymax = niceMax(Math.max(...vals, 1));
  const band = (W - m.l - m.r) / 12, bw = Math.min(20, Math.max(4, (band - 10) / 2));
  const y = v => m.t + (H - m.t - m.b) * (1 - v / ymax);
  const bar = (x0, v, c) => {
    if (!v) return "";
    const top = y(v), y0 = y(0), h = y0 - top, r = Math.min(4, h, bw / 2);
    return `<path d="M${x0},${y0}V${top + r}Q${x0},${top} ${x0 + r},${top}H${x0 + bw - r}Q${x0 + bw},${top} ${x0 + bw},${top + r}V${y0}Z" fill="${c}"/>`;
  };
  const tick = (x0, v) => v ? `<line x1="${x0 - 2}" x2="${x0 + bw + 2}" y1="${y(v)}" y2="${y(v)}" stroke="var(--surface)" stroke-width="5" stroke-linecap="round"/><line x1="${x0 - 2}" x2="${x0 + bw + 2}" y1="${y(v)}" y2="${y(v)}" stroke="var(--s-plan)" stroke-width="2" stroke-linecap="round"/>` : "";
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="月ごとの予算と実績">`;
  [0, 0.25, 0.5, 0.75, 1].forEach(f => { const t = f * ymax; svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="${f ? "var(--grid)" : "var(--axis)"}"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${fmt(t)}</text>`; });
  ms.forEach((x, i) => {
    const cx = m.l + band * (i + 0.5), xp = cx - bw - 1, xc = cx + 1;
    if (i === e.curMonthIndex) svg += `<rect x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="var(--cur)"/>`;
    svg += bar(xp, x.prevActual, "var(--s-prev)") + bar(xc, x.actual, "var(--s-actual)");
    svg += tick(xp, x.prevPlan) + tick(xc, x.plan);
    svg += `<text class="axis-text" x="${cx}" y="${H - 6}" text-anchor="middle">${MONTH_LABEL(x.month)}</text>`;
    svg += `<rect class="mb" data-i="${i}" x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="transparent"/>`;
  });
  box.innerHTML = svg + `</svg>`;
  box.querySelectorAll(".mb").forEach(r => {
    r.addEventListener("mousemove", ev => {
      const x = ms[+r.dataset.i];
      const row = (c, l, v) => `<div class="r"><span>${c ? `<i class="sw" style="background:var(${c})"></i>` : ""}${l}</span><span>${v == null ? "—" : fmt(v) + " h"}</span></div>`;
      showTip(`<div class="t">${x.ym.replace("-", "/")}</div>` + row("--s-actual", "今期 実績", x.actual) + row(null, "今期 予算", x.planOut ? null : x.plan) +
        row("--s-prev", "前年 実績", x.prevActual) + row(null, "前年 予算", x.prevPlan) +
        (x.prevActualToDate != null ? row(null, `前年 実績（〜${md(DATA.prevAsOf)}）`, x.prevActualToDate) : "") +
        (x.planOut ? `<div class="r"><span>予定表の範囲外</span><span></span></div>` : "") +
        (x.actual != null && prevCmp(x) != null ? `<div class="r"><span>実績の前年比${x.prevActualToDate != null ? "（同じ日まで）" : ""}</span><span>${fmtSigned(x.actual - prevCmp(x))} h</span></div>` : ""), ev.clientX, ev.clientY);
    });
    r.addEventListener("mouseleave", hideTip);
  });
}

// ---------- 内訳別の実績（個別設定で内訳名を2つ以上まとめた案件） ----------
const SPLIT_NONE = "（内訳なし）";
const splitName = l => l === "" ? SPLIT_NONE : l;
const splitColor = i => i < 8 ? `var(--bk-${i + 1})` : "var(--muted)";
// 予定の内訳ごとに、当たる実績の内訳（同じ名前か、「・」で区切った名前）をまとめる
function splitGroups(sp) {
  const al = sp.actual.map(a => a.label), used = new Set(), groups = [];
  sp.plan.forEach((p, pi) => {
    const parts = p.label.split("・").filter(x => x);
    const cov = al.map((l, i) => i).filter(i => !used.has(i) && (al[i] === p.label || parts.includes(al[i])));
    cov.forEach(i => used.add(i));
    groups.push({ plan: pi, acts: cov });
  });
  const rest = al.map((l, i) => i).filter(i => !used.has(i));
  if (rest.length) groups.push({ plan: -1, acts: rest });
  return groups;
}
function splitCard(e) {
  const sp = e.split, cm = e.curMonthIndex;
  const cur = i => i === cm ? " curcol" : "";
  const cells = (arr) => arr.map((v, i) => `<td class="num${cur(i)}">${v == null ? `<span class="muted">—</span>` : fmt(v)}</td>`).join("");
  const tot = arr => arr.reduce((s, v) => s + (v || 0), 0);
  let h = `<table class="mtable"><thead><tr><th>実績・予定（h）</th>${e.monthly.map((m, i) => `<th class="num${cur(i)}" title="${esc(m.ym)}">${MONTH_LABEL(m.month)}</th>`).join("")}<th class="num">合計</th></tr></thead><tbody>`;
  splitGroups(sp).forEach((g, gi) => {
    g.acts.forEach((i, k) => {
      const a = sp.actual[i];
      h += `<tr class="${gi > 0 && k === 0 ? "sep" : ""}"><td class="nw"><i class="bksw" style="background:${splitColor(i)}"></i>${esc(splitName(a.label))}</td>${cells(a.monthly)}<td class="num"><b>${fmt(tot(a.monthly))}</b></td></tr>`;
    });
    if (g.acts.length > 1) {
      const sub = e.monthly.map((m, j) => sp.actual[g.acts[0]].monthly[j] == null ? null : g.acts.reduce((s, i) => s + (sp.actual[i].monthly[j] || 0), 0));
      h += `<tr class="sub"><td class="nw">${esc(g.acts.map(i => splitName(sp.actual[i].label)).join("・"))} 小計</td>${cells(sub)}<td class="num"><b>${fmt(tot(sub))}</b></td></tr>`;
    }
    if (g.plan >= 0) {
      const p = sp.plan[g.plan];
      h += `<tr class="planrow${g.acts.length ? "" : (gi > 0 ? " sep" : "")}"><td class="nw">${esc(splitName(p.label))} 予定</td>${cells(p.monthly)}<td class="num">${fmt(tot(p.monthly))}</td></tr>`;
    }
  });
  h += `</tbody></table>`;
  // 人ごと
  let ph = `<table><thead><tr><th>役職</th><th>氏名</th>${sp.actual.map((a, i) => `<th class="num"><i class="bksw" style="background:${splitColor(i)}"></i>${esc(splitName(a.label))}</th>`).join("")}<th class="num">実績 計</th>${sp.plan.map(p => `<th class="num">予定 ${esc(splitName(p.label))}</th>`).join("")}<th class="num">差</th></tr></thead><tbody>`;
  const rk = Object.fromEntries(e.people.map(p => [p.name, p.rank]));
  ph += sp.people.map(p => {
    const a = tot(p.act), b = tot(p.plan), d = a - b;
    return `<tr><td>${esc(rk[p.name] || "")}</td><td class="nw">${esc(p.name)}</td>${p.act.map(v => `<td class="num">${fmt(v)}</td>`).join("")}<td class="num"><b>${fmt(a)}</b></td>${p.plan.map(v => `<td class="num">${fmt(v)}</td>`).join("")}<td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td></tr>`;
  }).join("") || `<tr><td colspan="${sp.actual.length + sp.plan.length + 4}" class="muted">まだありません</td></tr>`;
  ph += `</tbody></table>`;
  const cmLabel = e.monthly[cm] ? MONTH_LABEL(e.monthly[cm].month) : "";
  return `<div class="card" id="split-card">
    <h3>${esc(e.log && e.log.tagTitle ? e.log.tagTitle : "内訳")}別の実績（今期 ${esc(e.periodLabel)}）</h3>
    <div class="legend">${sp.actual.map((a, i) => `<span><i class="box" style="background:${splitColor(i)}"></i>${esc(splitName(a.label))}</span>`).join("")}<span><i style="background:var(--text)"></i>予定（全部の合計）</span></div>
    <div class="chart" id="c-split"></div>
    <div class="table-wrap" style="margin-top:8px">${h}</div>
    <div class="small" style="margin-top:4px">${cmLabel ? `${cmLabel}は ${md(DATA.asOf)} までの実績。` : ""}予定は予定表の行（まとめた案件）の単位でしか分けられないため、予定の行と、それに当たる実績（小計）を並べています。内訳は「個別設定」シートの内訳名です。</div>
    <h3 style="margin-top:18px">人ごとの${esc(e.log && e.log.tagTitle ? e.log.tagTitle : "内訳")}別の実績（〜${md(DATA.asOf)}）</h3>
    <div class="table-wrap">${ph}</div>
    <div class="small" style="margin-top:4px">予定は期の初め〜${md(DATA.asOf)} の分。差は実績の計と予定の計の差です。</div>
  </div>`;
}
function drawSplit(e) {
  const box = $("#c-split"); if (!box) return;
  const sp = e.split, W = box.clientWidth, H = 220, m = { l: 48, r: 12, t: 12, b: 24 };
  if (W < m.l + m.r + 60) { box.innerHTML = ""; return; }
  const n = e.monthly.length;
  const actTot = i => sp.actual.reduce((s, a) => s + (a.monthly[i] || 0), 0);
  const planTot = i => sp.plan.reduce((s, p) => s + (p.monthly[i] || 0), 0);
  // 棒はプラスの内訳だけを積む（マイナスは訂正の行。表とマウスを乗せたときに数字で出す）ので、軸もプラスの合計で決める
  const posTot = i => sp.actual.reduce((s, a) => s + Math.max(a.monthly[i] || 0, 0), 0);
  const ymax = niceMax(Math.max(1, ...e.monthly.map((x, i) => Math.max(posTot(i), planTot(i)))));
  const band = (W - m.l - m.r) / n, bw = Math.min(28, Math.max(6, band * 0.55));
  const y = v => m.t + (H - m.t - m.b) * (1 - v / ymax);
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="内訳別の月ごとの実績">`;
  [0, 0.25, 0.5, 0.75, 1].forEach(f => { const t = f * ymax; svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="${f ? "var(--grid)" : "var(--axis)"}"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${fmt(t)}</text>`; });
  e.monthly.forEach((x, i) => {
    const cx = m.l + band * (i + 0.5), x0 = cx - bw / 2;
    if (i === e.curMonthIndex) svg += `<rect x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="var(--cur)"/>`;
    let acc = 0;
    const segs = sp.actual.map((a, k) => [k, a.monthly[i] || 0]).filter(([, v]) => v > 0);
    segs.forEach(([k, v], j) => {
      const top = y(acc + v), bot = y(acc), hgt = Math.max(bot - top - (j ? 2 : 0), 0.5);
      if (j === segs.length - 1) {
        const r = Math.min(4, hgt, bw / 2);
        svg += `<path d="M${x0},${bot - (j ? 2 : 0)}V${top + r}Q${x0},${top} ${x0 + r},${top}H${x0 + bw - r}Q${x0 + bw},${top} ${x0 + bw},${top + r}V${bot - (j ? 2 : 0)}Z" fill="${splitColor(k)}"/>`;
      } else {
        svg += `<rect x="${x0}" y="${top}" width="${bw}" height="${hgt}" fill="${splitColor(k)}"/>`;
      }
      acc += v;
    });
    const pt = planTot(i);
    if (pt) svg += `<line x1="${x0 - 3}" x2="${x0 + bw + 3}" y1="${y(pt)}" y2="${y(pt)}" stroke="var(--surface)" stroke-width="5" stroke-linecap="round"/><line x1="${x0 - 3}" x2="${x0 + bw + 3}" y1="${y(pt)}" y2="${y(pt)}" stroke="var(--text)" stroke-width="2" stroke-linecap="round"/>`;
    svg += `<text class="axis-text" x="${cx}" y="${H - 6}" text-anchor="middle">${MONTH_LABEL(x.month)}</text>`;
    svg += `<rect class="sb" data-i="${i}" x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="transparent"/>`;
  });
  box.innerHTML = svg + `</svg>`;
  box.querySelectorAll(".sb").forEach(r => {
    r.addEventListener("mousemove", ev => {
      const i = +r.dataset.i, x = e.monthly[i];
      const row = (c, l, v) => `<div class="r"><span>${c ? `<i class="sw" style="background:${c}"></i>` : ""}${esc(l)}</span><span>${v == null ? "—" : fmt(v) + " h"}</span></div>`;
      showTip(`<div class="t">${x.ym.replace("-", "/")}</div>` + sp.actual.map((a, k) => row(splitColor(k), splitName(a.label), a.monthly[i])).join("") +
        row(null, "実績 計", sp.actual[0] && sp.actual[0].monthly[i] == null ? null : actTot(i)) +
        sp.plan.map(p => row(null, splitName(p.label) + " 予定", p.monthly[i])).join(""), ev.clientX, ev.clientY);
    });
    r.addEventListener("mouseleave", hideTip);
  });
}

// ---------- 人×週 ----------
function heatClass(plan, act) {
  if (!plan && !act) return "";
  if (plan && !act) return "heat-miss";
  const d = act - plan;
  if (Math.abs(d) < 0.5) return "heat-eq";
  const lv = Math.abs(d) >= 8 ? 3 : Math.abs(d) >= 4 ? 2 : 1;
  return (d > 0 ? "heat-over-" : "heat-under-") + lv;
}
function heatTable(e) {
  const cur = e.curWeekIndex, ws = e.weekly.slice(0, Math.max(0, cur + 1));
  if (!ws.length) return `<div class="muted">期はまだ始まっていません</div>`;
  let h =`<table class="heat"><thead><tr><th class="sticky">氏名</th>${ws.map((w, i) => {
    const first = i === 0 || w.wk.slice(0, 3) !== ws[i - 1].wk.slice(0, 3);
    return `<th class="num${first ? " mstart" : ""}" title="${w.wk}（${md(w.start)}〜${md(w.end)}）">${first ? (new Date(w.start).getMonth() + 1) + "月<br>" : "<br>"}${w.wk.slice(-2)}</th>`;
  }).join("")}<th class="num">計</th></tr></thead><tbody>`;
  e.people.forEach(p => {
    h += `<tr><td class="sticky">${esc(p.name)}${p.assigned ? "" : ` <span class="small">（アサイン外）</span>`}</td>`;
    ws.forEach((w, i) => {
      const plan = i === cur ? null : p.wPlan[i], act = p.wAct[i];
      const cls = i === cur ? (act ? "heat-eq" : "") : heatClass(plan, act);
      h += `<td class="num hc ${cls}" data-n="${esc(p.name)}" data-w="${i}" data-p="${p.wPlan[i]}" data-a="${act}">${act ? fmt(act) : ""}</td>`;
    });
    h += `<td class="num"><b>${fmt(p.actual)}</b></td></tr>`;
  });
  return h + `</tbody></table>`;
}
function bindHeatTips() {
  document.querySelectorAll("td.hc").forEach(td => {
    td.addEventListener("mousemove", ev => {
      const w = DATA.engagement.weekly[+td.dataset.w];
      showTip(`<div class="t">${esc(td.dataset.n)} · ${w.wk}（${md(w.start)}〜${md(w.end)}）</div><div class="r"><span>予定</span><span>${fmt(+td.dataset.p)} h</span></div><div class="r"><span>実績</span><span>${fmt(+td.dataset.a)} h</span></div><div class="r"><span>差</span><span>${fmtSigned(+td.dataset.a - +td.dataset.p)} h</span></div>`, ev.clientX, ev.clientY);
    });
    td.addEventListener("mouseleave", hideTip);
  });
}

// ---------- 残り期間の予定 ----------
const planLv = v => !v ? "" : v < 8 ? "pl-1" : v < 20 ? "pl-2" : v < 32 ? "pl-3" : "pl-4";
function renderRemaining(e) {
  const cur = e.curWeekIndex, from = Math.max(0, cur), compact = $("#rm-compact").checked;
  let idx = []; for (let i = from; i < e.weekly.length; i++) idx.push(i);
  const colTot = i => e.people.reduce((s, p) => s + (p.wPlan[i] || 0), 0);
  if (compact) idx = idx.filter(i => colTot(i) > 0);
  const people = e.people.filter(p => idx.some(i => p.wPlan[i]));
  const all = []; for (let i = from; i < e.weekly.length; i++) all.push(i);
  const total = all.reduce((s, i) => s + colTot(i), 0);
  $("#rm-sum").innerHTML = `残り ${all.length} 週・予定 <b>${fmt(total)} h</b>（${people.length} 人）`;
  $("#rm-compact").onchange = () => renderRemaining(e);
  if (!people.length) { $("#rm-wrap").innerHTML = `<div class="muted">期の終わりまでの予定はありません</div>`; return; }
  let h = `<table class="heat plan"><thead><tr><th class="sticky">氏名</th><th>役割</th><th class="num">残り計</th>${idx.map((i, k) => {
    const w = e.weekly[i], first = k === 0 || w.wk.slice(0, 3) !== e.weekly[idx[k - 1]].wk.slice(0, 3);
    return `<th class="num${first ? " mstart" : ""}${i === cur ? " curcol" : ""}" title="${w.wk}（${md(w.start)}〜${md(w.end)}）">${first ? (new Date(w.start).getMonth() + 1) + "月" : ""}<br>${i === cur ? "今週" : w.wk.slice(-2)}</th>`;
  }).join("")}</tr></thead><tbody>`;
  people.forEach(p => {
    const tot = all.reduce((s, i) => s + (p.wPlan[i] || 0), 0);
    h += `<tr><td class="sticky">${esc(p.name)}</td><td>${esc(p.role)}</td><td class="num"><b>${fmt(tot)}</b></td>${idx.map((i, k) => {
      const v = p.wPlan[i], first = k === 0 || e.weekly[i].wk.slice(0, 3) !== e.weekly[idx[k - 1]].wk.slice(0, 3);
      return `<td class="num hc ${planLv(v)}${first ? " mstart" : ""}">${v ? fmt(v) : ""}</td>`;
    }).join("")}</tr>`;
  });
  h += `<tr class="sep"><td class="sticky">合計</td><td></td><td class="num"><b>${fmt(total)}</b></td>${idx.map(i => `<td class="num"><b>${colTot(i) ? fmt(colTot(i)) : ""}</b></td>`).join("")}</tr>`;
  $("#rm-wrap").innerHTML = h + `</tbody></table>`;
}

// ---------- 実績ログ ----------
const LOG_PAGE = 200;
const LOG_COLS = [
  { k: "d", t: "日付" }, { k: "wk", t: "週" }, { k: "p", t: "氏名" }, { k: "r", t: "役職" },
  { k: "a", t: "作業内容" }, { k: "s", t: "摘要" }, { k: "h", t: "時間", num: true }, { k: "lc", t: "入力日" },
];
// 個別設定でまとめた案件は「内訳」か「元の案件」の列を氏名の後に足す
const LOG_TAG = (DATA.engagement.log && DATA.engagement.log.tagTitle) || "";
if (LOG_TAG) LOG_COLS.splice(3, 0, { k: "t", t: LOG_TAG });
const LG = { rows: [], view: [], shown: 0, sort: { k: "d", dir: -1 }, week: null };
const dayStr = off => { const d = new Date(DATA.engagement.periodStart); d.setDate(d.getDate() + off); return d; };   // 日の番号は期の初めから
const WD = "日月火水木金土";
function initLog(e) {
  const L = e.log || { people: [], ranks: [], acts: [], descs: [], rows: [] };
  LG.rows = L.rows.map(r => {
    const dt = dayStr(r[0]);
    const wi = r[7] != null ? r[7] : e.weekly.findIndex(w => dt >= new Date(w.start) && dt <= new Date(w.end));
    return { d: r[0], dt, wi, wk: wi >= 0 ? e.weekly[wi].wk : "", m: dt.getMonth() + 1, ym: dt.getFullYear() * 100 + dt.getMonth() + 1,
      p: L.people[r[1]], r: L.ranks[r[2]], a: L.acts[r[3]], s: L.descs[r[4]], h: r[5], lc: r[6],
      t: LOG_TAG ? (L.tags[r[8]] === "" && L.tagTitle === "内訳" ? SPLIT_NONE : L.tags[r[8]]) : "" };
  });
  const opt = (sel, vals, lab = v => v) => $(sel).insertAdjacentHTML("beforeend", vals.map(v => `<option value="${esc(v)}">${esc(lab(v))}</option>`).join(""));
  opt("#lg-p", e.people.map(p => p.name).filter(n => LG.rows.some(r => r.p === n)));
  opt("#lg-m", [...new Set(LG.rows.map(r => r.ym))].sort(), v => `${String(v).slice(0, 4)}年${+String(v).slice(4)}月`);
  opt("#lg-a", [...new Set(LG.rows.map(r => r.a))].sort());
  if (LOG_TAG) { opt("#lg-t", [...new Set(LG.rows.map(r => r.t))]); $("#lg-t").addEventListener("change", applyLog); }
  ["#lg-p", "#lg-m", "#lg-a"].forEach(s => $(s).addEventListener("change", applyLog));
  $("#lg-q").addEventListener("input", applyLog);
  $("#lg-csv").addEventListener("click", () => saveCsv(e));
  $("#lg-wrap").addEventListener("scroll", ev => { const w = ev.target; if (w.scrollTop + w.clientHeight > w.scrollHeight - 200) moreLog(); });
  // ヒートマップのマス → その人・その週に絞り込む
  document.querySelectorAll("table.heat:not(.plan) td.hc").forEach(td => {
    if (!(+td.dataset.a > 0)) return;   // 実績のあるマスだけ
    td.style.cursor = "pointer";
    td.addEventListener("click", () => {
      $("#lg-p").value = td.dataset.n; $("#lg-m").value = ""; $("#lg-a").value = ""; $("#lg-q").value = "";
      if (LOG_TAG) $("#lg-t").value = "";
      LG.week = +td.dataset.w; applyLog(); $("#log-card").scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
  applyLog();
}
function applyLog() {
  const p = $("#lg-p").value, m = $("#lg-m").value, a = $("#lg-a").value, q = $("#lg-q").value.trim().toLowerCase();
  const t = LOG_TAG ? $("#lg-t").value : "";
  const wk = LG.week;
  $("#lg-chip").innerHTML = wk == null ? "" : `<span class="chip">${esc(DATA.engagement.weekly[wk].wk)} の週だけ <button type="button" aria-label="週の絞り込みを外す">×</button></span>`;
  const b = $("#lg-chip button"); if (b) b.onclick = () => { LG.week = null; applyLog(); };
  LG.view = LG.rows.filter(r => (!p || r.p === p) && (!m || r.ym === +m) && (!a || r.a === a) && (!t || r.t === t) && (wk == null || r.wi === wk) &&
    (!q || (r.s + " " + r.a).toLowerCase().includes(q)));
  sortLog();
}
function sortLog() {
  const { k, dir } = LG.sort;
  LG.view.sort((x, y) => { const a = x[k] ?? "", b = y[k] ?? ""; return (a < b ? -1 : a > b ? 1 : 0) * dir || (x.d - y.d) * -1 || (x.p < y.p ? -1 : 1); });
  const tot = LG.view.reduce((s, r) => s + r.h, 0), all = LG.rows.reduce((s, r) => s + r.h, 0);
  $("#lg-sum").innerHTML = LG.view.length === LG.rows.length ? `${LG.rows.length.toLocaleString()} 件・<b>${fmt(all)} h</b>`
    : `${LG.view.length.toLocaleString()} 件・<b>${fmt(tot)} h</b>（全 ${LG.rows.length.toLocaleString()} 件・${fmt(all)} h）`;
  $("#lg-wrap thead").innerHTML = `<tr>${LOG_COLS.map(c => `<th class="sortable${c.num ? " num" : ""}" data-k="${c.k}">${c.t}${LG.sort.k === c.k ? `<span class="arrow">${LG.sort.dir > 0 ? " ▲" : " ▼"}</span>` : ""}</th>`).join("")}</tr>`;
  document.querySelectorAll("#lg-wrap th").forEach(th => th.onclick = () => {
    const k = th.dataset.k; LG.sort = { k, dir: LG.sort.k === k ? -LG.sort.dir : (k === "d" || k === "h" || k === "lc" ? -1 : 1) }; sortLog();
  });
  $("#lg-wrap tbody").innerHTML = LG.view.length ? "" : `<tr><td colspan="${LOG_COLS.length}" class="muted">${LG.rows.length ? "該当する実績はありません" : "この案件の実績はまだありません"}</td></tr>`;
  LG.shown = 0; $("#lg-wrap").scrollTop = 0; moreLog();
}
function moreLog() {
  if (LG.shown >= LG.view.length) return;
  const part = LG.view.slice(LG.shown, LG.shown + LOG_PAGE); LG.shown += part.length;
  $("#lg-wrap tbody").insertAdjacentHTML("beforeend", part.map(r => `<tr><td class="nw">${md(r.dt).slice(5)}（${WD[r.dt.getDay()]}）</td><td class="nw">${esc(r.wk)}</td><td class="nw">${esc(r.p)}</td>${LOG_TAG ? `<td class="nw">${esc(r.t)}</td>` : ""}<td class="nw">${esc(r.r)}</td><td>${esc(r.a)}</td><td>${esc(r.s)}</td><td class="num">${fmt(r.h)}</td><td class="nw muted">${r.lc == null ? "" : md(dayStr(r.lc)).slice(5)}</td></tr>`).join(""));
}
function saveCsv(e) {
  const q = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const lines = [["日付", "週", "氏名"].concat(LOG_TAG ? [LOG_TAG] : [], ["役職", "作業内容", "摘要", "時間", "入力日"]).join(",")].concat(
    LG.view.map(r => [md(r.dt), r.wk, r.p].concat(LOG_TAG ? [r.t] : [], [r.r, r.a, r.s, r.h, r.lc == null ? "" : md(dayStr(r.lc))]).map(q).join(",")));
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv" });
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${e.id}_実績ログ.csv`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- 役職別 ----------
function ranksTable(e) {
  let h = `<table><thead><tr><th>役職</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">前年同時期</th><th class="num">前年比</th><th class="num">通期予定</th><th class="num">前年通期</th></tr></thead><tbody>`;
  const tot = { planToDate: 0, actual: 0, prevToDate: 0, planFull: 0, prevFull: 0 };
  e.ranks.forEach(r => {
    Object.keys(tot).forEach(k => tot[k] += r[k]);
    const d = r.actual - r.planToDate, y = r.actual - r.prevToDate;
    h += `<tr><td>${esc(r.rank)}</td><td class="num">${fmt(r.planToDate)}</td><td class="num">${fmt(r.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td><td class="num">${e.prev ? fmt(r.prevToDate) : "—"}</td>
      <td class="num ${y > 0 ? "over" : y < 0 ? "under" : ""}">${e.prev ? fmtSigned(y) : "—"}</td><td class="num">${fmt(r.planFull)}</td><td class="num">${e.prev ? fmt(r.prevFull) : "—"}</td></tr>`;
  });
  const d = tot.actual - tot.planToDate, y = tot.actual - tot.prevToDate;
  h += `<tr class="sep"><td>合計</td><td class="num"><b>${fmt(tot.planToDate)}</b></td><td class="num"><b>${fmt(tot.actual)}</b></td><td class="num"><b>${fmtSigned(d)}</b></td>
    <td class="num"><b>${e.prev ? fmt(tot.prevToDate) : "—"}</b></td><td class="num"><b>${e.prev ? fmtSigned(y) : "—"}</b></td><td class="num"><b>${fmt(tot.planFull)}</b></td><td class="num"><b>${e.prev ? fmt(tot.prevFull) : "—"}</b></td></tr>`;
  return h + `</tbody></table><div class="small" style="margin-top:4px">予定は人の役職（当年度の実績表）で、実績は入力時の役職で分けています。</div>`;
}


function buildNotes(e) {
  const n = [];
  if (e.planToDate > 0 && Math.abs(e.rate) > T.varRate)
    n.push(`${ICON_WARN} 実績が予定より <b>${fmtPct(e.rate)}</b>（${fmtSigned(e.diff)} h）${e.rate > 0 ? "多い" : "少ない"}`);
  e.people.filter(p => !p.assigned).forEach(p => n.push(`${ICON_CRIT} <b>${esc(p.name)}</b> はアサインされていないが ${fmt(p.actual)} h チャージ`));
  e.people.filter(p => p.assigned && p.planToDate >= 8 && p.actual === 0).forEach(p => n.push(`${ICON_WARN} <b>${esc(p.name)}</b> は予定 ${fmt(p.planToDate)} h に対して実績なし`));
  const missed = e.people.filter(p => p.assigned && p.missedDays >= 5).sort((a, b) => b.missedDays - a.missedDays);
  if (missed.length) n.push(`${ICON_WARN} 予定日に実績がない日が多い人: ${missed.map(p => `${esc(p.name)}（${p.missedDays}日）`).join("、")}`);
  const big = e.weekly.filter(w => w.actual != null && Math.abs(w.actual - w.planToDate) > T.weekVarHours);
  if (big.length) n.push(`${ICON_WARN} 差が ±${T.weekVarHours}h を超えた週: ${big.map(w => `${w.wk}（${fmtSigned(w.actual - w.planToDate)}h）`).join("、")}`);
  if (e.prev && e.prev.full && e.forecast > e.prev.full * 1.2) n.push(`${ICON_WARN} 着地見込みが前年通期の ${(e.forecast / e.prev.full * 100).toFixed(0)}%`);
  if (e.prevPartial) n.push(`${ICON_WARN} 前年の期（${esc(e.prevLabel)}）の一部が入力ファイル（実績表）の範囲外のため、前年の数字は欠けた分だけ少なく出ています`);
  if (e.planOutside) n.push(`${ICON_WARN} ${esc(e.planOutside)} は予定表の範囲外のため、予定 0 として集計しています`);
  return n;
}

function peopleTable(e) {
  return `<table><thead><tr><th>氏名</th><th>役割</th><th>役職</th><th>チーム</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">通期予定</th><th class="num">予定日に実績なし</th><th>注意</th></tr></thead><tbody>` +
    e.people.map(p => { const d = p.actual - p.planToDate; const f = personFlags(p); return `<tr>
      <td>${esc(p.name)}</td><td>${esc(p.role)}</td><td>${esc(p.rank)}</td><td>${esc(p.team)}</td>
      <td class="num">${fmt(p.planToDate)}</td><td class="num">${fmt(p.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td><td class="num">${fmt(p.planFull)}</td>
      <td class="num">${p.assigned ? p.missedDays + " 日" : "—"}</td><td>${f.map(flagHtml).join("") || `<span class="muted">—</span>`}</td></tr>`; }).join("") +
    `</tbody></table>`;
}

function weeklyTable(e) {
  let cp = 0, ca = 0;
  return `<table><thead><tr><th>週</th><th>期間</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">累積予定</th><th class="num">累積実績</th></tr></thead><tbody>` +
    e.weekly.map(w => { cp += w.plan; if (w.actual != null) ca += w.actual; const d = w.actual == null ? null : w.actual - w.planToDate;
      return `<tr><td>${w.wk}</td><td>${md(w.start)}〜${md(w.end)}</td><td class="num">${fmt(w.plan)}</td><td class="num">${fmt(w.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${d == null ? "—" : fmtSigned(d)}</td><td class="num">${fmt(cp)}</td><td class="num">${w.actual == null ? "—" : fmt(ca)}</td></tr>`; }).join("") +
    `</tbody></table>`;
}

function actBars(e) {
  if (!e.activities.length) return `<div class="muted">実績なし</div>`;
  const max = Math.max(...e.activities.map(a => a[1]));
  return e.activities.map(([n, v]) => `<div class="actbar"><span class="name" title="${esc(n)}">${esc(n)}</span>
    <span class="track"><span class="bar" style="display:block;width:${max ? v / max * 100 : 0}%"></span></span><span class="v">${fmt(v)} h</span></div>`).join("");
}


// ---------- グラフ ----------
function drawCumulative(e) {
  const box = $("#c-cum"); const W = box.clientWidth, H = 260, m = { l: 48, r: 16, t: 10, b: 26 };
  if (W < m.l + m.r + 60) { box.innerHTML = ""; return; }   // 幅が取れないうちは描かない
  const n = e.weekly.length, inPer = e.curWeekIndex >= 0 && e.curWeekIndex < n, cur = Math.min(e.curWeekIndex, n - 1);   // cur: 実績のある最後の週（-1=まだ）
  let s = 0; const plan = e.weekly.map(w => (s += w.plan));
  s = 0; const act = e.weekly.map((w, i) => i <= cur ? (s += w.actual || 0) : null);
  s = 0; const prev = e.prev ? e.prev.weekly.slice(0, n).map(v => (s += v)) : [];
  const ymax = niceMax(Math.max(...plan, ...act.filter(v => v != null), ...prev, 1));
  const x = i => m.l + (W - m.l - m.r) * (n === 1 ? 0 : i / (n - 1));
  const y = v => m.t + (H - m.t - m.b) * (1 - v / ymax);
  const path = arr => arr.map((v, i) => v == null ? null : `${x(i).toFixed(1)},${y(v).toFixed(1)}`).filter(Boolean).map((p, i) => (i ? "L" : "M") + p).join("");
  const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => f * ymax);
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="累積時間のグラフ">`;
  ticks.forEach(t => svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)" stroke-width="1"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${fmt(t)}</text>`);
  svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(0)}" y2="${y(0)}" stroke="var(--axis)" stroke-width="1"/>`;
  monthTicks(e.weekly).forEach(t => svg += `<text class="axis-text" x="${x(t.i)}" y="${H - 6}" text-anchor="middle">${t.label}</text>`);
  if (inPer) svg += `<line x1="${x(cur)}" x2="${x(cur)}" y1="${m.t}" y2="${y(0)}" stroke="var(--axis)" stroke-width="1"/><text class="axis-text" x="${x(cur) + 4}" y="${m.t + 10}">${md(DATA.asOf)}</text>`;
  if (prev.length) svg += `<path d="${path(prev)}" fill="none" stroke="var(--s-prev)" stroke-width="2" stroke-dasharray="6 4" stroke-linejoin="round"/>`;
  svg += `<path d="${path(plan)}" fill="none" stroke="var(--s-plan)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
  if (cur >= 0) {
    svg += `<path d="${path(act)}" fill="none" stroke="var(--s-actual)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
    svg += `<circle cx="${x(cur)}" cy="${y(act[cur])}" r="4" fill="var(--s-actual)" stroke="var(--surface)" stroke-width="2"/>`;
    svg += `<text class="axis-text" x="${x(cur) - 6}" y="${y(act[cur]) - 8}" text-anchor="end" style="fill:var(--text)">実績 ${fmt(act[cur])}</text>`;
  }
  svg += `<g id="hover" style="display:none"><line id="hx" y1="${m.t}" y2="${y(0)}" stroke="var(--muted)" stroke-width="1"/><circle id="hp" r="4" fill="var(--s-plan)" stroke="var(--surface)" stroke-width="2"/><circle id="ha" r="4" fill="var(--s-actual)" stroke="var(--surface)" stroke-width="2"/><circle id="hv" r="4" fill="var(--s-prev)" stroke="var(--surface)" stroke-width="2"/></g>`;
  svg += `<rect x="${m.l}" y="${m.t}" width="${W - m.l - m.r}" height="${H - m.t - m.b}" fill="transparent" id="hit"/></svg>`;
  box.innerHTML = svg;
  const g = $("#hover", box), hit = $("#hit", box);
  hit.addEventListener("mousemove", ev => {
    const r = box.getBoundingClientRect(); const px = (ev.clientX - r.left) * (W / r.width);
    const i = Math.max(0, Math.min(n - 1, Math.round((px - m.l) / (W - m.l - m.r) * (n - 1))));
    g.style.display = ""; $("#hx", g).setAttribute("x1", x(i)); $("#hx", g).setAttribute("x2", x(i));
    const set = (id, v) => { const c = $(id, g); if (v == null) c.style.display = "none"; else { c.style.display = ""; c.setAttribute("cx", x(i)); c.setAttribute("cy", y(v)); } };
    set("#hp", plan[i]); set("#ha", act[i]); set("#hv", prev[i]);
    const w = e.weekly[i];
    const row = (c, l, v) => `<div class="r"><span><i class="sw" style="background:var(${c})"></i>${l}</span><span>${v == null ? "—" : fmt(v) + " h"}</span></div>`;
    showTip(`<div class="t">${w.wk}（${md(w.start)}〜${md(w.end)}）</div>` + row("--s-plan", "累積予定", plan[i]) + row("--s-actual", "累積実績", act[i]) + (prev.length ? row("--s-prev", "前年累積", prev[i]) : ""), ev.clientX, ev.clientY);
  });
  hit.addEventListener("mouseleave", () => { g.style.display = "none"; hideTip(); });
}

function drawDiff(e) {
  const box = $("#c-diff"); const W = box.clientWidth, H = 180, m = { l: 48, r: 16, t: 14, b: 26 };
  if (W < m.l + m.r + 60) { box.innerHTML = ""; return; }   // 幅が取れないうちは描かない
  const ws = e.weekly.slice(0, Math.max(0, e.curWeekIndex + 1));
  if (!ws.length) { box.innerHTML = `<div class="muted">期はまだ始まっていません</div>`; return; }
  const d = ws.map(w => (w.actual || 0) - w.planToDate);
  const lim = niceMax(Math.max(...d.map(Math.abs), T.weekVarHours));
  const n = ws.length, band = (W - m.l - m.r) / n, bw = Math.min(24, Math.max(3, band - 2));
  const y = v => m.t + (H - m.t - m.b) * (1 - (v + lim) / (2 * lim));
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="週ごとの差のグラフ">`;
  [-lim, -lim / 2, 0, lim / 2, lim].forEach(t => svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="${t === 0 ? "var(--axis)" : "var(--grid)"}" stroke-width="1"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${t > 0 ? "+" : t < 0 ? "−" : ""}${fmt(Math.abs(t))}</text>`);
  monthTicks(ws).forEach(t => svg += `<text class="axis-text" x="${m.l + band * (t.i + 0.5)}" y="${H - 6}" text-anchor="middle">${t.label}</text>`);
  d.forEach((v, i) => {
    const cx = m.l + band * (i + 0.5), x0 = cx - bw / 2, y0 = y(0), y1 = y(v), h = Math.abs(y1 - y0);
    if (h >= 0.5) {
      const r = Math.min(4, h, bw / 2), up = v > 0, top = up ? y1 : y0, c = up ? "var(--over)" : "var(--under)";
      const p = up ? `M${x0},${y0}V${top + r}Q${x0},${top} ${x0 + r},${top}H${x0 + bw - r}Q${x0 + bw},${top} ${x0 + bw},${top + r}V${y0}Z`
                   : `M${x0},${y0}V${y1 - r}Q${x0},${y1} ${x0 + r},${y1}H${x0 + bw - r}Q${x0 + bw},${y1} ${x0 + bw},${y1 - r}V${y0}Z`;
      svg += `<path d="${p}" fill="${c}"/>`;
      if (Math.abs(v) > T.weekVarHours) svg += `<text class="axis-text" style="fill:var(--text)" x="${cx}" y="${up ? y1 - 4 : y1 + 12}" text-anchor="middle">${fmtSigned(v)}</text>`;
    }
    svg += `<rect class="hb" data-i="${i}" x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="transparent"/>`;
  });
  svg += `</svg>`;
  box.innerHTML = svg;
  box.querySelectorAll(".hb").forEach(r => {
    r.addEventListener("mousemove", ev => { const i = +r.dataset.i, w = ws[i];
      showTip(`<div class="t">${w.wk}（${md(w.start)}〜${md(w.end)}）</div><div class="r"><span>予定</span><span>${fmt(w.planToDate)} h${w.planToDate !== w.plan ? "（〜" + md(DATA.asOf) + "）" : ""}</span></div><div class="r"><span>実績</span><span>${fmt(w.actual)} h</span></div><div class="r"><span>差</span><span>${fmtSigned(d[i])} h</span></div>`, ev.clientX, ev.clientY);
      r.setAttribute("fill", "var(--hover)"); });
    r.addEventListener("mouseleave", () => { hideTip(); r.setAttribute("fill", "transparent"); });
  });
}

// ---------- 起動 ----------
const E = DATA.engagement;
E.diff = E.actual - E.planToDate; E.rate = pct(E.actual, E.planToDate);
// 人の並び: 役割の順（EP → EM → EIC → CETS → ETS → AA → その他 → アサイン外）。同じ役割の中は今までの順（予定の多い順）
const ROLE_ORDER = ["EP", "EM", "EIC", "CETS", "ETS", "AA"];
const roleRank = p => {
  if (!p.assigned) return 1000;
  const rs = String(p.role || "").split("/").map(r => ROLE_ORDER.indexOf(r.trim())).filter(i => i >= 0);
  return rs.length ? Math.min(...rs) : 100;
};
E.people = E.people.map((p, i) => ({ p, i })).sort((a, b) => (roleRank(a.p) - roleRank(b.p)) || (a.i - b.i)).map(x => x.p);
document.title = `${E.name}${E.mergeLabel ? "（" + E.mergeLabel + "）" : ""} | エンゲージメント分析 ${DATA.fy} ${DATA.reportWeek}`;
$("#subtitle").textContent = subtitle(E);
$("#footer").innerHTML = footerHtml();
renderDetail(E);
// グラフは幅に合わせて描くので、幅が変わったら描き直す（裏のタブで開いて幅が 0 だったときも、表示されたときに描き直す）
let rt, lastW = $("#c-month").clientWidth;
const redrawCharts = () => { drawMonthly(E); drawSplit(E); drawCumulative(E); drawDiff(E); };
const onWidth = () => { const w = $("#c-month").clientWidth; if (w === lastW) return; lastW = w; clearTimeout(rt); rt = setTimeout(redrawCharts, 120); };
if (window.ResizeObserver) new ResizeObserver(onWidth).observe($("#c-month"));
addEventListener("resize", onWidth);
document.addEventListener("visibilitychange", onWidth);
