
function renderDetail(e) {
  const el = $("#detail");
  const budgetNote = e.budget == null ? "予定表に予算の入力なし"
    : (e.budgetRows < e.rows ? `予算の入力は ${e.budgetRows} / ${e.rows} 人分` : "");
  const tiles = [
    ["予算", e.budget == null ? "—" : fmt(e.budget) + " h",
      e.budget == null ? budgetNote : `消化 ${(e.actual / e.budget * 100).toFixed(1)}% · 着地 ${(e.forecast / e.budget * 100).toFixed(0)}%` + (budgetNote ? `（${budgetNote}）` : "")],
    ["予定（〜" + md(DATA.asOf) + "）", fmt(e.planToDate) + " h", `通期予定 ${fmt(e.planFull)} h`],
    ["実績", fmt(e.actual) + " h", `予定比 ${fmtPct(e.rate)}（${fmtSigned(e.diff)} h）`],
    ["着地見込み", fmt(e.forecast) + " h", "実績＋今後の予定"],
    ["前年同時期", e.prev ? fmt(e.prev.toDate) + " h" : "—", e.prev ? `今年は ${fmtPct(pct(e.actual, e.prev.toDate))}（${fmtSigned(e.actual - e.prev.toDate)} h）` : "前年の案件なし"],
    ["前年通期", e.prev ? fmt(e.prev.full) + " h" : "—", e.prev ? `着地見込みは ${fmtPct(pct(e.forecast, e.prev.full))}（${fmtSigned(e.forecast - e.prev.full)} h）` : ""],
  ];
  const notes = buildNotes(e);
  const cur = DATA.currentWeekIndex;
  el.innerHTML = `
  <div class="card">
    <h1 class="engtitle">${esc(e.name)} <span class="small">${esc(e.id)}</span>${e.noPlan ? ` <span class="badge">予定表にない案件（実績のみ）</span>` : ""}</h1>
    <div class="meta">
      <span>クライアント <b>${esc(e.client)}</b>（${esc(e.clientCode)}）</span>
      <span>管理グループ <b>${esc(e.group)}</b></span><span>決算月 <b>${esc(e.fyEnd)}</b></span>
      <span>EP <b>${esc(e.ep.join("・") || "—")}</b></span><span>EM <b>${esc(e.em.join("・") || "—")}</b></span>
      <span>前年案件 <b>${e.prev ? esc(e.prev.name) + "（" + esc(e.prev.id) + "）" : "—"}</b></span>
    </div>
    <div class="tiles">${tiles.map(tileHtml).join("")}</div>
  </div>
  <div class="card">
    <h3>注意が要るもの</h3>
    ${notes.length ? `<ul class="notes">${notes.map(n => `<li>${n}</li>`).join("")}</ul>` : `<div class="muted">特になし</div>`}
  </div>
  <div class="card">
    <h3>月ごとの予算と実績（${esc(DATA.fy)} と ${esc(DATA.prevFy)}）</h3>
    <div class="legend"><span><i class="box" style="background:var(--s-prev)"></i>${esc(DATA.prevFy)} 実績</span><span><i class="box" style="background:var(--s-actual)"></i>${esc(DATA.fy)} 実績</span><span><i class="tick"></i>予算（予定表の月合計）</span></div>
    <div class="chart" id="c-month"></div>
    <div class="table-wrap" style="margin-top:8px">${monthlyTable(e)}</div>
    <div class="small" style="margin-top:4px">${MONTH_LABEL(e.monthly[e.curMonthIndex].month)}は ${md(DATA.asOf)} までの実績。前年比は、前年も ${md(DATA.prevAsOf)} までの実績で比べています（${DATA.prevFy} 実績の行は月全体）。</div>
  </div>
  <div class="card">
    <h3>累積時間（予定・実績・前年実績）</h3>
    <div class="legend"><span><i style="background:var(--s-plan)"></i>予定</span><span><i style="background:var(--s-actual)"></i>実績</span>${e.prev ? `<span><i class="dash"></i>前年実績（${esc(DATA.prevFy)}）</span>` : ""}</div>
    <div class="chart" id="c-cum"></div>
  </div>
  <div class="card">
    <h3>人ごと・週ごとの実績（色は予定との差）</h3>
    <div class="legend"><span><i class="box" style="background:var(--heat-over-2)"></i>予定より多い</span><span><i class="box" style="background:var(--heat-under-2)"></i>予定より少ない</span><span><i class="box heat-miss-box"></i>予定ありで実績なし</span><span>数字は実績（h）。マウスを乗せると予定も表示</span></div>
    <div class="table-wrap">${heatTable(e)}</div>
    <div class="small" style="margin-top:4px">今週（${e.weekly[cur].wk}）は途中のため色を付けていません。</div>
  </div>
  <div class="grid2">
    <div class="card">
      <h3>今後4週間の予定</h3>
      <div class="table-wrap">${upcomingTable(e)}</div>
    </div>
    <div class="card">
      <h3>役職別の予定と実績</h3>
      <div class="table-wrap">${ranksTable(e)}</div>
    </div>
  </div>
  <div class="card">
    <h3>人ごとの予定と実績</h3>
    <div class="table-wrap">${peopleTable(e)}</div>
  </div>
  <div class="grid2">
    <div class="card">
      <h3>週ごとの差（実績 − 予定）</h3>
      <div class="legend"><span><i class="box" style="background:var(--over)"></i>予定より多い</span><span><i class="box" style="background:var(--under)"></i>予定より少ない</span><span>±${T.weekVarHours}h 超は数値を表示</span></div>
      <div class="chart" id="c-diff"></div>
      <details><summary>週ごとの数値を表で見る</summary><div class="table-wrap" style="margin-top:8px">${weeklyTable(e)}</div></details>
    </div>
    <div class="card">
      <h3>作業内容の内訳（実績）</h3>
      ${actBars(e)}
    </div>
  </div>`;
  drawMonthly(e);
  drawCumulative(e);
  drawDiff(e);
  bindHeatTips();
  const hw = $("table.heat").parentElement;   // 最新の週が見えるよう右端までスクロール
  hw.scrollLeft = hw.scrollWidth;
}

// ---------- 月ごと ----------
const MONTH_LABEL = m => m + "月";
// 前年比に使う前年の実績（今月は前年も同じ日まで）
const prevCmp = m => m.prevActualToDate != null ? m.prevActualToDate : m.prevActual;
function monthlyTable(e) {
  const sum = (k) => e.monthly.reduce((s, m) => s + (m[k] || 0), 0);
  const has = (k) => e.monthly.some(m => m[k] != null);
  const rows = [
    ["予算", "plan", DATA.fy], ["実績", "actual", DATA.fy],
    ["予算", "prevPlan", DATA.prevFy], ["実績", "prevActual", DATA.prevFy],
  ];
  let h = `<table class="mtable"><thead><tr><th></th><th></th>${e.monthly.map((m, i) => `<th class="num${i === e.curMonthIndex ? " curcol" : ""}">${MONTH_LABEL(m.month)}</th>`).join("")}<th class="num">合計</th></tr></thead><tbody>`;
  rows.forEach(([lbl, k, fy], ri) => {
    h += `<tr class="${ri === 2 ? "sep" : ""}"><td>${esc(fy)}</td><td>${lbl}</td>` + e.monthly.map((m, i) => `<td class="num${i === e.curMonthIndex ? " curcol" : ""}">${m[k] == null ? `<span class="muted">—</span>` : fmt(m[k])}</td>`).join("") +
      `<td class="num"><b>${has(k) ? fmt(sum(k)) : "—"}</b></td></tr>`;
  });
  // 実績の前年比
  h += `<tr class="sep"><td colspan="2">実績の前年比</td>` + e.monthly.map((m, i) => {
    if (m.actual == null || prevCmp(m) == null) return `<td class="num${i === e.curMonthIndex ? " curcol" : ""}"><span class="muted">—</span></td>`;
    const d = m.actual - prevCmp(m);
    return `<td class="num${i === e.curMonthIndex ? " curcol" : ""} ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td>`;
  }).join("") + `<td></td></tr>`;
  return h + `</tbody></table>`;
}

function drawMonthly(e) {
  const box = $("#c-month"); const W = box.clientWidth, H = 220, m = { l: 48, r: 12, t: 12, b: 24 };
  const ms = e.monthly;
  const vals = ms.flatMap(x => [x.plan, x.actual, x.prevPlan, x.prevActual].filter(v => v != null));
  const ymax = niceMax(Math.max(...vals, 1));
  const band = (W - m.l - m.r) / 12, bw = Math.min(20, Math.max(4, (band - 10) / 2));
  const y = v => m.t + (H - m.t - m.b) * (1 - v / ymax);
  const bar = (x0, v, c) => {
    if (!v) return "";
    const top = y(v), y0 = y(0), h = y0 - top, r = Math.min(4, h, bw / 2);
    return `<path d="M${x0},${y0}V${top + r}Q${x0},${top} ${x0 + r},${top}H${x0 + bw - r}Q${x0 + bw},${top} ${x0 + bw},${top + r}V${y0}Z" fill="${c}"/>`;
  };
  const tick = (x0, v) => v ? `<line x1="${x0 - 2}" x2="${x0 + bw + 2}" y1="${y(v)}" y2="${y(v)}" stroke="var(--surface)" stroke-width="5" stroke-linecap="round"/><line x1="${x0 - 2}" x2="${x0 + bw + 2}" y1="${y(v)}" y2="${y(v)}" stroke="var(--s-plan)" stroke-width="2" stroke-linecap="round"/>` : "";
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="月ごとの予算と実績">`;
  [0, 0.25, 0.5, 0.75, 1].forEach(f => { const t = f * ymax; svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="${f ? "var(--grid)" : "var(--axis)"}"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${fmt(t)}</text>`; });
  ms.forEach((x, i) => {
    const cx = m.l + band * (i + 0.5), xp = cx - bw - 1, xc = cx + 1;
    if (i === e.curMonthIndex) svg += `<rect x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="var(--cur)"/>`;
    svg += bar(xp, x.prevActual, "var(--s-prev)") + bar(xc, x.actual, "var(--s-actual)");
    svg += tick(xp, x.prevPlan) + tick(xc, x.plan);
    svg += `<text class="axis-text" x="${cx}" y="${H - 6}" text-anchor="middle">${MONTH_LABEL(x.month)}</text>`;
    svg += `<rect class="mb" data-i="${i}" x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="transparent"/>`;
  });
  box.innerHTML = svg + `</svg>`;
  box.querySelectorAll(".mb").forEach(r => {
    r.addEventListener("mousemove", ev => {
      const x = ms[+r.dataset.i];
      const row = (c, l, v) => `<div class="r"><span>${c ? `<i class="sw" style="background:var(${c})"></i>` : ""}${l}</span><span>${v == null ? "—" : fmt(v) + " h"}</span></div>`;
      showTip(`<div class="t">${MONTH_LABEL(x.month)}</div>` + row("--s-actual", `${DATA.fy} 実績`, x.actual) + row(null, `${DATA.fy} 予算`, x.plan) +
        row("--s-prev", `${DATA.prevFy} 実績`, x.prevActual) + row(null, `${DATA.prevFy} 予算`, x.prevPlan) +
        (x.prevActualToDate != null ? row(null, `${DATA.prevFy} 実績（〜${md(DATA.prevAsOf)}）`, x.prevActualToDate) : "") +
        (x.actual != null && prevCmp(x) != null ? `<div class="r"><span>実績の前年比${x.prevActualToDate != null ? "（同じ日まで）" : ""}</span><span>${fmtSigned(x.actual - prevCmp(x))} h</span></div>` : ""), ev.clientX, ev.clientY);
    });
    r.addEventListener("mouseleave", hideTip);
  });
}

// ---------- 人×週 ----------
function heatClass(plan, act) {
  if (!plan && !act) return "";
  if (plan && !act) return "heat-miss";
  const d = act - plan;
  if (Math.abs(d) < 0.5) return "heat-eq";
  const lv = Math.abs(d) >= 8 ? 3 : Math.abs(d) >= 4 ? 2 : 1;
  return (d > 0 ? "heat-over-" : "heat-under-") + lv;
}
function heatTable(e) {
  const cur = DATA.currentWeekIndex, ws = e.weekly.slice(0, cur + 1);
  let h = `<table class="heat"><thead><tr><th class="sticky">氏名</th>${ws.map((w, i) => {
    const first = i === 0 || w.wk.slice(0, 3) !== ws[i - 1].wk.slice(0, 3);
    return `<th class="num${first ? " mstart" : ""}" title="${w.wk}（${md(w.start)}〜${md(w.end)}）">${first ? (new Date(w.start).getMonth() + 1) + "月<br>" : "<br>"}${w.wk.slice(-2)}</th>`;
  }).join("")}<th class="num">計</th></tr></thead><tbody>`;
  e.people.forEach(p => {
    h += `<tr><td class="sticky">${esc(p.name)}${p.assigned ? "" : ` <span class="small">（アサイン外）</span>`}</td>`;
    ws.forEach((w, i) => {
      const plan = i === cur ? null : p.wPlan[i], act = p.wAct[i];
      const cls = i === cur ? (act ? "heat-eq" : "") : heatClass(plan, act);
      h += `<td class="num hc ${cls}" data-n="${esc(p.name)}" data-w="${i}" data-p="${p.wPlan[i]}" data-a="${act}">${act ? fmt(act) : ""}</td>`;
    });
    h += `<td class="num"><b>${fmt(p.actual)}</b></td></tr>`;
  });
  return h + `</tbody></table>`;
}
function bindHeatTips() {
  document.querySelectorAll("td.hc").forEach(td => {
    td.addEventListener("mousemove", ev => {
      const w = DATA.engagement.weekly[+td.dataset.w];
      showTip(`<div class="t">${esc(td.dataset.n)} · ${w.wk}（${md(w.start)}〜${md(w.end)}）</div><div class="r"><span>予定</span><span>${fmt(+td.dataset.p)} h</span></div><div class="r"><span>実績</span><span>${fmt(+td.dataset.a)} h</span></div><div class="r"><span>差</span><span>${fmtSigned(+td.dataset.a - +td.dataset.p)} h</span></div>`, ev.clientX, ev.clientY);
    });
    td.addEventListener("mouseleave", hideTip);
  });
}

// ---------- 今後4週間 ----------
function upcomingTable(e) {
  const cur = DATA.currentWeekIndex;
  const idx = [1, 2, 3, 4].map(k => cur + k).filter(i => i < e.weekly.length);
  if (!idx.length) return `<div class="muted">年度末までの週がありません</div>`;
  const people = e.people.filter(p => idx.some(i => p.wPlan[i]));
  let h = `<table><thead><tr><th>氏名</th>${idx.map(i => `<th class="num" title="${md(e.weekly[i].start)}〜${md(e.weekly[i].end)}">${e.weekly[i].wk}<br><span class="small">${md(e.weekly[i].start).slice(5)}〜</span></th>`).join("")}<th class="num">計</th></tr></thead><tbody>`;
  if (!people.length) return h + `<tr><td colspan="${idx.length + 2}" class="muted">この4週間の予定はありません</td></tr></tbody></table>`;
  people.forEach(p => {
    const tot = idx.reduce((s, i) => s + p.wPlan[i], 0);
    h += `<tr><td>${esc(p.name)}</td>${idx.map(i => `<td class="num">${p.wPlan[i] ? fmt(p.wPlan[i]) : `<span class="muted">—</span>`}</td>`).join("")}<td class="num"><b>${fmt(tot)}</b></td></tr>`;
  });
  const colTot = idx.map(i => e.people.reduce((s, p) => s + p.wPlan[i], 0));
  h += `<tr class="sep"><td>合計</td>${colTot.map(v => `<td class="num"><b>${fmt(v)}</b></td>`).join("")}<td class="num"><b>${fmt(colTot.reduce((a, b) => a + b, 0))}</b></td></tr>`;
  return h + `</tbody></table>`;
}

// ---------- 役職別 ----------
function ranksTable(e) {
  let h = `<table><thead><tr><th>役職</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">前年同時期</th><th class="num">前年比</th><th class="num">通期予定</th><th class="num">前年通期</th></tr></thead><tbody>`;
  const tot = { planToDate: 0, actual: 0, prevToDate: 0, planFull: 0, prevFull: 0 };
  e.ranks.forEach(r => {
    Object.keys(tot).forEach(k => tot[k] += r[k]);
    const d = r.actual - r.planToDate, y = r.actual - r.prevToDate;
    h += `<tr><td>${esc(r.rank)}</td><td class="num">${fmt(r.planToDate)}</td><td class="num">${fmt(r.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td><td class="num">${e.prev ? fmt(r.prevToDate) : "—"}</td>
      <td class="num ${y > 0 ? "over" : y < 0 ? "under" : ""}">${e.prev ? fmtSigned(y) : "—"}</td><td class="num">${fmt(r.planFull)}</td><td class="num">${e.prev ? fmt(r.prevFull) : "—"}</td></tr>`;
  });
  const d = tot.actual - tot.planToDate, y = tot.actual - tot.prevToDate;
  h += `<tr class="sep"><td>合計</td><td class="num"><b>${fmt(tot.planToDate)}</b></td><td class="num"><b>${fmt(tot.actual)}</b></td><td class="num"><b>${fmtSigned(d)}</b></td>
    <td class="num"><b>${e.prev ? fmt(tot.prevToDate) : "—"}</b></td><td class="num"><b>${e.prev ? fmtSigned(y) : "—"}</b></td><td class="num"><b>${fmt(tot.planFull)}</b></td><td class="num"><b>${e.prev ? fmt(tot.prevFull) : "—"}</b></td></tr>`;
  return h + `</tbody></table><div class="small" style="margin-top:4px">予定は人の役職（当年度の実績表）で、実績は入力時の役職で分けています。</div>`;
}


function buildNotes(e) {
  const n = [];
  if (e.planToDate > 0 && Math.abs(e.rate) > T.varRate)
    n.push(`${ICON_WARN} 実績が予定より <b>${fmtPct(e.rate)}</b>（${fmtSigned(e.diff)} h）${e.rate > 0 ? "多い" : "少ない"}`);
  e.people.filter(p => !p.assigned).forEach(p => n.push(`${ICON_CRIT} <b>${esc(p.name)}</b> はアサインされていないが ${fmt(p.actual)} h チャージ`));
  e.people.filter(p => p.assigned && p.planToDate >= 8 && p.actual === 0).forEach(p => n.push(`${ICON_WARN} <b>${esc(p.name)}</b> は予定 ${fmt(p.planToDate)} h に対して実績なし`));
  const missed = e.people.filter(p => p.assigned && p.missedDays >= 5).sort((a, b) => b.missedDays - a.missedDays);
  if (missed.length) n.push(`${ICON_WARN} 予定日に実績がない日が多い人: ${missed.map(p => `${esc(p.name)}（${p.missedDays}日）`).join("、")}`);
  const big = e.weekly.filter(w => w.actual != null && Math.abs(w.actual - w.planToDate) > T.weekVarHours);
  if (big.length) n.push(`${ICON_WARN} 差が ±${T.weekVarHours}h を超えた週: ${big.map(w => `${w.wk}（${fmtSigned(w.actual - w.planToDate)}h）`).join("、")}`);
  if (e.prev && e.prev.full && e.forecast > e.prev.full * 1.2) n.push(`${ICON_WARN} 着地見込みが前年通期の ${(e.forecast / e.prev.full * 100).toFixed(0)}%`);
  return n;
}

function peopleTable(e) {
  return `<table><thead><tr><th>氏名</th><th>役割</th><th>役職</th><th>チーム</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">通期予定</th><th class="num">予定日に実績なし</th><th>注意</th></tr></thead><tbody>` +
    e.people.map(p => { const d = p.actual - p.planToDate; const f = personFlags(p); return `<tr>
      <td>${esc(p.name)}</td><td>${esc(p.role)}</td><td>${esc(p.rank)}</td><td>${esc(p.team)}</td>
      <td class="num">${fmt(p.planToDate)}</td><td class="num">${fmt(p.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</td><td class="num">${fmt(p.planFull)}</td>
      <td class="num">${p.assigned ? p.missedDays + " 日" : "—"}</td><td>${f.map(flagHtml).join("") || `<span class="muted">—</span>`}</td></tr>`; }).join("") +
    `</tbody></table>`;
}

function weeklyTable(e) {
  let cp = 0, ca = 0;
  return `<table><thead><tr><th>週</th><th>期間</th><th class="num">予定</th><th class="num">実績</th><th class="num">差</th><th class="num">累積予定</th><th class="num">累積実績</th></tr></thead><tbody>` +
    e.weekly.map(w => { cp += w.plan; if (w.actual != null) ca += w.actual; const d = w.actual == null ? null : w.actual - w.planToDate;
      return `<tr><td>${w.wk}</td><td>${md(w.start)}〜${md(w.end)}</td><td class="num">${fmt(w.plan)}</td><td class="num">${fmt(w.actual)}</td>
      <td class="num ${d > 0 ? "over" : d < 0 ? "under" : ""}">${d == null ? "—" : fmtSigned(d)}</td><td class="num">${fmt(cp)}</td><td class="num">${w.actual == null ? "—" : fmt(ca)}</td></tr>`; }).join("") +
    `</tbody></table>`;
}

function actBars(e) {
  if (!e.activities.length) return `<div class="muted">実績なし</div>`;
  const max = Math.max(...e.activities.map(a => a[1]));
  return e.activities.map(([n, v]) => `<div class="actbar"><span class="name" title="${esc(n)}">${esc(n)}</span>
    <span class="track"><span class="bar" style="display:block;width:${max ? v / max * 100 : 0}%"></span></span><span class="v">${fmt(v)} h</span></div>`).join("");
}


// ---------- グラフ ----------
function drawCumulative(e) {
  const box = $("#c-cum"); const W = box.clientWidth, H = 260, m = { l: 48, r: 16, t: 10, b: 26 };
  const n = e.weekly.length, cur = DATA.currentWeekIndex;
  let s = 0; const plan = e.weekly.map(w => (s += w.plan));
  s = 0; const act = e.weekly.map((w, i) => i <= cur ? (s += w.actual || 0) : null);
  s = 0; const prev = e.prev ? e.prev.weekly.slice(0, n).map(v => (s += v)) : [];
  const ymax = niceMax(Math.max(...plan, ...act.filter(v => v != null), ...prev, 1));
  const x = i => m.l + (W - m.l - m.r) * (n === 1 ? 0 : i / (n - 1));
  const y = v => m.t + (H - m.t - m.b) * (1 - v / ymax);
  const path = arr => arr.map((v, i) => v == null ? null : `${x(i).toFixed(1)},${y(v).toFixed(1)}`).filter(Boolean).map((p, i) => (i ? "L" : "M") + p).join("");
  const ticks = [0, 0.25, 0.5, 0.75, 1].map(f => f * ymax);
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="累積時間のグラフ">`;
  ticks.forEach(t => svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="var(--grid)" stroke-width="1"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${fmt(t)}</text>`);
  svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(0)}" y2="${y(0)}" stroke="var(--axis)" stroke-width="1"/>`;
  monthTicks(e.weekly).forEach(t => svg += `<text class="axis-text" x="${x(t.i)}" y="${H - 6}" text-anchor="middle">${t.label}</text>`);
  svg += `<line x1="${x(cur)}" x2="${x(cur)}" y1="${m.t}" y2="${y(0)}" stroke="var(--axis)" stroke-width="1"/><text class="axis-text" x="${x(cur) + 4}" y="${m.t + 10}">${md(DATA.asOf)}</text>`;
  if (prev.length) svg += `<path d="${path(prev)}" fill="none" stroke="var(--s-prev)" stroke-width="2" stroke-dasharray="6 4" stroke-linejoin="round"/>`;
  svg += `<path d="${path(plan)}" fill="none" stroke="var(--s-plan)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
  svg += `<path d="${path(act)}" fill="none" stroke="var(--s-actual)" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>`;
  svg += `<circle cx="${x(cur)}" cy="${y(act[cur])}" r="4" fill="var(--s-actual)" stroke="var(--surface)" stroke-width="2"/>`;
  svg += `<text class="axis-text" x="${x(cur) - 6}" y="${y(act[cur]) - 8}" text-anchor="end" style="fill:var(--text)">実績 ${fmt(act[cur])}</text>`;
  svg += `<g id="hover" style="display:none"><line id="hx" y1="${m.t}" y2="${y(0)}" stroke="var(--muted)" stroke-width="1"/><circle id="hp" r="4" fill="var(--s-plan)" stroke="var(--surface)" stroke-width="2"/><circle id="ha" r="4" fill="var(--s-actual)" stroke="var(--surface)" stroke-width="2"/><circle id="hv" r="4" fill="var(--s-prev)" stroke="var(--surface)" stroke-width="2"/></g>`;
  svg += `<rect x="${m.l}" y="${m.t}" width="${W - m.l - m.r}" height="${H - m.t - m.b}" fill="transparent" id="hit"/></svg>`;
  box.innerHTML = svg;
  const g = $("#hover", box), hit = $("#hit", box);
  hit.addEventListener("mousemove", ev => {
    const r = box.getBoundingClientRect(); const px = (ev.clientX - r.left) * (W / r.width);
    const i = Math.max(0, Math.min(n - 1, Math.round((px - m.l) / (W - m.l - m.r) * (n - 1))));
    g.style.display = ""; $("#hx", g).setAttribute("x1", x(i)); $("#hx", g).setAttribute("x2", x(i));
    const set = (id, v) => { const c = $(id, g); if (v == null) c.style.display = "none"; else { c.style.display = ""; c.setAttribute("cx", x(i)); c.setAttribute("cy", y(v)); } };
    set("#hp", plan[i]); set("#ha", act[i]); set("#hv", prev[i]);
    const w = e.weekly[i];
    const row = (c, l, v) => `<div class="r"><span><i class="sw" style="background:var(${c})"></i>${l}</span><span>${v == null ? "—" : fmt(v) + " h"}</span></div>`;
    showTip(`<div class="t">${w.wk}（${md(w.start)}〜${md(w.end)}）</div>` + row("--s-plan", "累積予定", plan[i]) + row("--s-actual", "累積実績", act[i]) + (prev.length ? row("--s-prev", "前年累積", prev[i]) : ""), ev.clientX, ev.clientY);
  });
  hit.addEventListener("mouseleave", () => { g.style.display = "none"; hideTip(); });
}

function drawDiff(e) {
  const box = $("#c-diff"); const W = box.clientWidth, H = 180, m = { l: 48, r: 16, t: 14, b: 26 };
  const ws = e.weekly.slice(0, DATA.currentWeekIndex + 1);
  const d = ws.map(w => (w.actual || 0) - w.planToDate);
  const lim = niceMax(Math.max(...d.map(Math.abs), T.weekVarHours));
  const n = ws.length, band = (W - m.l - m.r) / n, bw = Math.min(24, Math.max(3, band - 2));
  const y = v => m.t + (H - m.t - m.b) * (1 - (v + lim) / (2 * lim));
  let svg = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="週ごとの差のグラフ">`;
  [-lim, -lim / 2, 0, lim / 2, lim].forEach(t => svg += `<line x1="${m.l}" x2="${W - m.r}" y1="${y(t)}" y2="${y(t)}" stroke="${t === 0 ? "var(--axis)" : "var(--grid)"}" stroke-width="1"/><text class="axis-text" x="${m.l - 6}" y="${y(t) + 4}" text-anchor="end">${t > 0 ? "+" : t < 0 ? "−" : ""}${fmt(Math.abs(t))}</text>`);
  monthTicks(ws).forEach(t => svg += `<text class="axis-text" x="${m.l + band * (t.i + 0.5)}" y="${H - 6}" text-anchor="middle">${t.label}</text>`);
  d.forEach((v, i) => {
    const cx = m.l + band * (i + 0.5), x0 = cx - bw / 2, y0 = y(0), y1 = y(v), h = Math.abs(y1 - y0);
    if (h >= 0.5) {
      const r = Math.min(4, h, bw / 2), up = v > 0, top = up ? y1 : y0, c = up ? "var(--over)" : "var(--under)";
      const p = up ? `M${x0},${y0}V${top + r}Q${x0},${top} ${x0 + r},${top}H${x0 + bw - r}Q${x0 + bw},${top} ${x0 + bw},${top + r}V${y0}Z`
                   : `M${x0},${y0}V${y1 - r}Q${x0},${y1} ${x0 + r},${y1}H${x0 + bw - r}Q${x0 + bw},${y1} ${x0 + bw},${y1 - r}V${y0}Z`;
      svg += `<path d="${p}" fill="${c}"/>`;
      if (Math.abs(v) > T.weekVarHours) svg += `<text class="axis-text" style="fill:var(--text)" x="${cx}" y="${up ? y1 - 4 : y1 + 12}" text-anchor="middle">${fmtSigned(v)}</text>`;
    }
    svg += `<rect class="hb" data-i="${i}" x="${m.l + band * i}" y="${m.t}" width="${band}" height="${H - m.t - m.b}" fill="transparent"/>`;
  });
  svg += `</svg>`;
  box.innerHTML = svg;
  box.querySelectorAll(".hb").forEach(r => {
    r.addEventListener("mousemove", ev => { const i = +r.dataset.i, w = ws[i];
      showTip(`<div class="t">${w.wk}（${md(w.start)}〜${md(w.end)}）</div><div class="r"><span>予定</span><span>${fmt(w.planToDate)} h${w.planToDate !== w.plan ? "（〜" + md(DATA.asOf) + "）" : ""}</span></div><div class="r"><span>実績</span><span>${fmt(w.actual)} h</span></div><div class="r"><span>差</span><span>${fmtSigned(d[i])} h</span></div>`, ev.clientX, ev.clientY);
      r.setAttribute("fill", "var(--hover)"); });
    r.addEventListener("mouseleave", () => { hideTip(); r.setAttribute("fill", "transparent"); });
  });
}

// ---------- 起動 ----------
const E = DATA.engagement;
E.diff = E.actual - E.planToDate; E.rate = pct(E.actual, E.planToDate);
// 人の並び: 役割の順（EP → EM → EIC → CETS → ETS → AA → その他 → アサイン外）。同じ役割の中は今までの順（予定の多い順）
const ROLE_ORDER = ["EP", "EM", "EIC", "CETS", "ETS", "AA"];
const roleRank = p => {
  if (!p.assigned) return 1000;
  const rs = String(p.role || "").split("/").map(r => ROLE_ORDER.indexOf(r.trim())).filter(i => i >= 0);
  return rs.length ? Math.min(...rs) : 100;
};
E.people = E.people.map((p, i) => ({ p, i })).sort((a, b) => (roleRank(a.p) - roleRank(b.p)) || (a.i - b.i)).map(x => x.p);
document.title = `${E.name} | エンゲージメント分析 ${DATA.fy} ${DATA.reportWeek}`;
$("#subtitle").textContent = subtitle();
$("#footer").innerHTML = footerHtml();
renderDetail(E);
// グラフは幅に合わせて描くので、幅が変わったら描き直す（裏のタブで開いて幅が 0 だったときも、表示されたときに描き直す）
let rt, lastW = $("#c-month").clientWidth;
const redrawCharts = () => { drawMonthly(E); drawCumulative(E); drawDiff(E); };
const onWidth = () => { const w = $("#c-month").clientWidth; if (w === lastW) return; lastW = w; clearTimeout(rt); rt = setTimeout(redrawCharts, 120); };
if (window.ResizeObserver) new ResizeObserver(onWidth).observe($("#c-month"));
addEventListener("resize", onWidth);
document.addEventListener("visibilitychange", onWidth);
