// ---------- 一覧ページ ----------
DATA.engagements.forEach(e => {
  e.diff = e.actual - e.planToDate; e.rate = pct(e.actual, e.planToDate);
  e.yoyTD = e.prev ? e.actual - e.prev.toDate : null;          // 同時期の増減
  e.yoyFull = e.prev ? e.forecast - e.prev.full : null;        // 着地見込み − 前年通期
});
document.title = `エンゲージメント一覧 ${DATA.fy} ${DATA.reportWeek}`;
$("#title").textContent = `エンゲージメント一覧 ${DATA.fy}`;
$("#subtitle").textContent = subtitle();
$("#footer").innerHTML = footerHtml();
// 入力ファイルが足りないときの注記（例: 前々年度の実績表が無く、前年の一部が欠ける）
if (DATA.notes && DATA.notes.length)
  $("#totals").insertAdjacentHTML("afterend", `<section class="card"><ul class="notes">${DATA.notes.map(n => `<li>${ICON_WARN} ${esc(n)}</li>`).join("")}</ul></section>`);

function renderTotals(list) {
  const s = k => list.reduce((a, e) => a + (e[k] || 0), 0);
  const plan = s("planToDate"), actual = s("actual"), forecast = s("forecast");
  const withPrev = list.filter(e => e.prev);
  const prevTD = withPrev.reduce((a, e) => a + e.prev.toDate, 0), prevFull = withPrev.reduce((a, e) => a + e.prev.full, 0);
  const actWP = withPrev.reduce((a, e) => a + e.actual, 0), fcWP = withPrev.reduce((a, e) => a + e.forecast, 0);
  const withBudget = list.filter(e => e.budget != null), budget = withBudget.reduce((a, e) => a + e.budget, 0);
  const flagged = list.filter(e => e.flags.length).length;
  $("#totals").innerHTML = [
    ["予算", withBudget.length ? fmt(budget) + " h" : "—", withBudget.length ? `予算の入力がある ${withBudget.length} 件の合計` : "予算の入力なし"],
    ["実績（〜" + md(DATA.asOf) + "）", fmt(actual) + " h", `予定 ${fmt(plan)} h に対して ${fmtPct(pct(actual, plan))}`],
    ["前年同時期との比較", withPrev.length ? fmtPct(pct(actWP, prevTD)) : "—", withPrev.length ? `${fmt(actWP)} h ／ 前年 ${fmt(prevTD)} h（${fmtSigned(actWP - prevTD)} h）` : "前年の案件なし"],
    ["前年通期との比較", withPrev.length ? fmtPct(pct(fcWP, prevFull)) : "—", withPrev.length ? `着地見込み ${fmt(fcWP)} h ／ 前年 ${fmt(prevFull)} h` : ""],
    ["要確認の案件", `${flagged} / ${list.length}`, "予定との差・アサイン外チャージ"],
  ].map(tileHtml).join("");
}

const yoyHtml = (d, base) => d == null ? `<span class="muted">—</span>` :
  `<span class="${d > 0 ? "over" : d < 0 ? "under" : ""}">${fmtSigned(d)}</span><div class="small">${fmtPct(base ? d / base : null)}</div>`;
const COLS = [
  { key: "name", label: "案件", get: e => e.name, html: e => `<a class="englink" href="${encodeURI(e.file)}">${esc(e.name)}${e.mergeLabel ? `<span class="muted">（${esc(e.mergeLabel)}）</span>` : ""}</a>${e.noPlan ? ` <span class="badge">予定表にない</span>` : ""}<div class="small">${esc(e.id)} · ${esc(e.client)}${e.mergeNote ? ` · まとめた案件: ${esc(e.mergeNote)}` : ""}</div>` },
  { key: "em", label: "EM", get: e => e.em.join("・"), html: e => esc(e.em.join("・") || "—") },
  { key: "fyEnd", label: "決算月", get: e => parseInt(e.fyEnd), html: e => esc(e.fyEnd) },
  { key: "period", label: "期間", get: e => e.periodStart, html: e => `<span class="nw">${esc(e.periodLabel)}</span>` +
      (e.prevPartial ? ` <span class="small muted" title="前年の期の一部が入力ファイルの範囲外">※</span>` : "") },
  { key: "budget", label: "予算", num: true, get: e => e.budget ?? -1, html: e => e.budget == null ? `<span class="muted">—</span>` : fmt(e.budget) },
  { key: "planToDate", label: "予定", num: true, get: e => e.planToDate },
  { key: "actual", label: "実績", num: true, get: e => e.actual },
  { key: "rate", label: "予定比", num: true, get: e => e.rate ?? -999, html: e => `<span class="${e.diff > 0 ? "over" : e.diff < 0 ? "under" : ""}">${fmtPct(e.rate)}</span>` },
  { key: "forecast", label: "着地見込み", num: true, get: e => e.forecast },
  { key: "prevToDate", label: "前年同時期", num: true, get: e => e.prev ? e.prev.toDate : -1, html: e => e.prev ? fmt(e.prev.toDate) : `<span class="muted">—</span>` },
  { key: "yoyTD", label: "同時期の増減", num: true, get: e => e.yoyTD ?? -1e9, html: e => yoyHtml(e.yoyTD, e.prev && e.prev.toDate) },
  { key: "prevFull", label: "前年通期", num: true, get: e => e.prev ? e.prev.full : -1, html: e => e.prev ? fmt(e.prev.full) : `<span class="muted">—</span>` },
  { key: "yoyFull", label: "通期の増減", num: true, get: e => e.yoyFull ?? -1e9, html: e => yoyHtml(e.yoyFull, e.prev && e.prev.full) },
  { key: "flags", label: "注意", get: e => e.flags.length, html: e => e.flags.map(flagHtml).join("") || `<span class="muted">—</span>` },
];
let sort = { key: "fyEnd", dir: 1 };

function filtered() {
  const em = $("#f-em").value, ep = $("#f-ep").value, fye = $("#f-fye").value, g = $("#f-group").value;
  const q = $("#f-q").value.trim().toLowerCase(), onlyFlag = $("#f-flag").checked;
  return DATA.engagements.filter(e =>
    (!em || e.em.includes(em)) && (!ep || e.ep.includes(ep)) && (!fye || e.fyEnd === fye) && (!g || e.group === g) &&
    (!q || (e.name + e.client + e.id + (e.mergeNote || "") + (e.mergeLabel || "")).toLowerCase().includes(q)) && (!onlyFlag || e.flags.length));
}
function renderTable() {
  const list = filtered();
  const col = COLS.find(c => c.key === sort.key);
  list.sort((a, b) => { const x = col.get(a), y = col.get(b); return (x > y ? 1 : x < y ? -1 : 0) * sort.dir || a.id.localeCompare(b.id); });
  $("#eng-table thead").innerHTML = "<tr>" + COLS.map(c =>
    `<th class="sortable ${c.num ? "num" : ""}" data-key="${c.key}">${c.label}${c.num && !["rate"].includes(c.key) ? "<span class='small muted'> h</span>" : ""}<span class="arrow">${sort.key === c.key ? (sort.dir > 0 ? "▲" : "▼") : ""}</span></th>`).join("") + "</tr>";
  $("#eng-table tbody").innerHTML = list.length ? list.map(e => `<tr class="eng" data-file="${esc(e.file)}">` +
    COLS.map(c => `<td class="${c.num ? "num" : ""}">${c.html ? c.html(e) : (c.num ? fmt(c.get(e)) : esc(c.get(e)))}</td>`).join("") + "</tr>").join("")
    : `<tr><td colspan="${COLS.length}" class="empty">該当する案件はありません</td></tr>`;
  $("#table-note").textContent = `${list.length} 件 · 数字は案件ごとの期（決算月の3か月後から12か月。「期間」の列）で集計 · 案件名（または行）を押すとその案件のページを開きます · 見出しを押すと並べ替え · 同時期の増減＝今期の実績−前年の期の同じ日までの実績、通期の増減＝着地見込み−前年通期` +
    (list.some(e => e.prevPartial) ? " · ※＝前年の期の一部が入力ファイルの範囲外" : "");
  renderTotals(list);
}
$("#eng-table thead").addEventListener("click", ev => {
  const th = ev.target.closest("th"); if (!th) return;
  sort = { key: th.dataset.key, dir: sort.key === th.dataset.key ? -sort.dir : (COLS.find(c => c.key === th.dataset.key).num ? -1 : 1) };
  renderTable();
});
$("#eng-table tbody").addEventListener("click", ev => {
  if (ev.target.closest("a")) return;
  const tr = ev.target.closest("tr.eng"); if (tr) location.href = encodeURI(tr.dataset.file);
});

// 絞り込みの選択肢: どれか（例えば管理グループ）を選ぶと、ほかの選択肢（EM・EP・決算月）は、それに当てはまる案件にあるものだけになる
const FILTERS = [
  { sel: "#f-em", get: e => e.em },
  { sel: "#f-ep", get: e => e.ep },
  { sel: "#f-fye", get: e => [e.fyEnd], num: true },
  { sel: "#f-group", get: e => [e.group] },
];
const matchF = (e, f, v) => !v || f.get(e).includes(v);
function refreshOptions() {
  const cur = FILTERS.map(f => $(f.sel).value);
  FILTERS.forEach((f, fi) => {
    const list = DATA.engagements.filter(e => FILTERS.every((g, gi) => gi === fi || matchF(e, g, cur[gi])));
    let vals = [...new Set(list.flatMap(f.get))].filter(Boolean);
    vals.sort(f.num ? (a, b) => parseInt(a) - parseInt(b) : (a, b) => a.localeCompare(b, "ja"));
    if (cur[fi] && !vals.includes(cur[fi])) vals.unshift(cur[fi]);
    $(f.sel).innerHTML = `<option value="">すべて</option>` + vals.map(v => `<option${v === cur[fi] ? " selected" : ""}>${esc(v)}</option>`).join("");
  });
}
refreshOptions();
// 前回選んだ EM を覚えておく（このブラウザだけ）
const EM_KEY = "engagement-report-em";
try { const v = localStorage.getItem(EM_KEY); if (v && [...$("#f-em").options].some(o => o.value === v)) { $("#f-em").value = v; refreshOptions(); } } catch (e) {}
$("#f-em").addEventListener("change", () => { try { localStorage.setItem(EM_KEY, $("#f-em").value); } catch (e) {} });
FILTERS.forEach(f => $(f.sel).addEventListener("change", () => { refreshOptions(); renderTable(); }));
["#f-q", "#f-flag"].forEach(s => $(s).addEventListener("input", renderTable));
renderTable();
