// ---------- 共通（一覧・案件ページで共用） ----------
const $ = (s, el = document) => el.querySelector(s);
const fmt = v => v == null ? "—" : Number(v).toLocaleString("ja-JP", { maximumFractionDigits: 1, minimumFractionDigits: 0 });
const fmtSigned = v => (v > 0 ? "+" : v < 0 ? "−" : "±") + fmt(Math.abs(v));
const pct = (a, b) => b ? (a - b) / b : null;
const fmtPct = v => v == null ? "—" : (v > 0 ? "+" : v < 0 ? "−" : "±") + Math.abs(v * 100).toFixed(1) + "%";
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const md = s => { const d = new Date(s); return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`; };
const cssVar = n => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const T = DATA.thresholds;
const subtitle = () => `実績 ${md(DATA.fyStart)}〜${md(DATA.asOf)}（${DATA.reportWeek}）· 前年比較 ${DATA.prevFy}（〜${md(DATA.prevAsOf)}） · 作成 ${DATA.generatedAt}`;
const footerHtml = () => `元データ: ${DATA.sources.map(esc).join(" / ")}<br>予定・実績は ${md(DATA.asOf)} までを比較。差の判定は ±${T.varRate * 100}% 、週の差の目印は ±${T.weekVarHours}h。`;
const tileHtml = ([l, v, d]) => `<div class="tile"><div class="label">${esc(l)}</div><div class="value">${v}</div>${d ? `<div class="delta">${esc(d)}</div>` : ""}</div>`;

const ICON_WARN = `<svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true"><path d="M8 1.5 15 14H1z" fill="var(--warn)"/><path d="M8 6v3.5M8 11.3v.2" stroke="#2E2E38" stroke-width="1.6" stroke-linecap="round"/></svg>`;
const ICON_CRIT = `<svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="7" fill="var(--crit)"/><path d="M8 4.5v4.2M8 11v.2" stroke="#fff" stroke-width="1.6" stroke-linecap="round"/></svg>`;
const flagHtml = (f) => `<span class="flag">${f.level === "crit" ? ICON_CRIT : ICON_WARN}${esc(f.label)}</span>`;

function personFlags(p) {
  const f = [];
  if (!p.assigned) f.push({ level: "crit", label: "アサイン外" });
  else if (p.planToDate >= 8 && p.actual === 0) f.push({ level: "warn", label: "実績なし" });
  else if (p.planToDate >= 16 && Math.abs(pct(p.actual, p.planToDate)) > 0.3) f.push({ level: "warn", label: "差が大きい" });
  return f;
}

const tip = $("#tip");
function showTip(html, x, y) {
  tip.innerHTML = html; tip.style.display = "block";
  const r = tip.getBoundingClientRect();
  let left = x + 14, top = y + 14;
  if (left + r.width > innerWidth - 8) left = x - r.width - 14;
  if (top + r.height > innerHeight - 8) top = y - r.height - 14;
  tip.style.left = Math.max(8, left) + "px"; tip.style.top = Math.max(8, top) + "px";
}
const hideTip = () => tip.style.display = "none";

function niceMax(v) {
  if (v <= 0) return 10;
  const p = Math.pow(10, Math.floor(Math.log10(v))), n = v / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p;
}
function monthTicks(weeks) {
  const out = [];
  weeks.forEach((w, i) => { const p = w.wk.slice(0, 3); if (!out.length || out[out.length - 1].p !== p) out.push({ p, i, label: (new Date(w.start).getMonth() + 1) + "月" }); });
  return out;
}
const S = "http://www.w3.org/2000/svg";

